/* Preview harness only. In the real project, render <HomePage />
   from its existing router instead. */
import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import HomePage from './components/HomePage';

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <HomePage />
  </StrictMode>
);
