import { useReveal } from '../../motion/hooks';
import ArtworkPlaceholder from './ArtworkPlaceholder';

/**
 * Static painting in a clean circular crop. No border, no shadow.
 * Reveals with a slow iris opening when it enters the viewport.
 * `index` staggers neighbours on wide screens only.
 */
export default function CircularArtwork({ asset, size, position, index = 0, alt = '', className = '' }) {
  const ref = useReveal();
  const pos = position || asset.focal?.desktop || '50% 50%';

  return (
    <figure
      ref={ref}
      className={`circle-art ${className}`.trim()}
      style={{
        ...(size ? { '--circle-size': size } : null),
        '--circle-pos': pos,
        '--i': index,
      }}
    >
      <div className="circle-art__disc">
        {asset.ready?.poster ? (
          <img src={asset.files.poster} alt={alt} loading="lazy" decoding="async" />
        ) : (
          <ArtworkPlaceholder asset={asset} compact />
        )}
      </div>
    </figure>
  );
}
