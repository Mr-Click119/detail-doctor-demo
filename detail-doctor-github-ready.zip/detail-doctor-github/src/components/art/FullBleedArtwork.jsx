import { useEffect, useRef } from 'react';
import {
  DESKTOP,
  useMediaQuery,
  useNearViewport,
  useReducedMotion,
  useScrollProgress,
} from '../../motion/hooks';
import ArtworkPlaceholder from './ArtworkPlaceholder';

/**
 * Edge-to-edge painting. No frame, radius, or shadow.
 *
 * fill:
 *   "viewport"  — at least one full viewport tall
 *   "container" — sized by the manifest aspect ratio (desktop/mobile)
 *   "fill"      — absolutely fills its positioned parent
 *
 * Motion (all disabled under prefers-reduced-motion):
 *   parallax    px of vertical drift across the element's pass through view
 *   scaleFrom → scaleTo   scroll-linked scale
 *   track=false inherit --progress from an ancestor (e.g. a sticky stage)
 *
 * Video plays only when: asset is "moving", its files are marked ready,
 * the viewport is desktop-width, motion is allowed, and the section is
 * near the viewport. It pauses when mostly off-screen.
 */
export default function FullBleedArtwork({
  asset,
  fill = 'viewport',
  overlay,
  parallax = 0,
  scaleFrom = 1,
  scaleTo = 1,
  track = true,
  eager = false,
  as: Tag = 'div',
  className = '',
  style,
  children,
  ...rest
}) {
  const reduced = useReducedMotion();
  const desktop = useMediaQuery(DESKTOP, true);
  const moves = parallax > 0 || scaleFrom !== scaleTo;
  const progressRef = useScrollProgress('pass', track && moves);
  const [nearRef, near, visible] = useNearViewport('400px');
  const videoRef = useRef(null);

  const hasPoster = Boolean(asset.ready?.poster);
  const allowVideo =
    asset.kind === 'moving' && Boolean(asset.ready?.video) && !reduced && desktop;
  const overlayValue = overlay ?? asset.overlay ?? 0;

  const setRef = (node) => {
    progressRef.current = node;
    nearRef.current = node;
  };

  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    if (visible) {
      const p = v.play();
      if (p && typeof p.catch === 'function') p.catch(() => {});
    } else {
      v.pause();
    }
  }, [visible, near, allowVideo]);

  const [fx = '50%', fy = '50%'] = (asset.focal?.desktop || '').split(' ');
  const [mx = fx, my = fy] = (asset.focal?.mobile || '').split(' ');

  return (
    <Tag
      ref={setRef}
      className={`art art--${fill} ${className}`.trim()}
      style={{
        '--overlay': overlayValue,
        '--parallax': `${parallax}px`,
        '--scale-from': scaleFrom,
        '--scale-to': scaleTo,
        '--obj-pos': `${fx} ${fy}`,
        '--obj-pos-m': `${mx} ${my}`,
        '--aspect': asset.aspect?.desktop,
        '--aspect-m': asset.aspect?.mobile,
        ...style,
      }}
      {...rest}
    >
      <div className="art__layer" aria-hidden="true">
        {hasPoster ? (
          <picture>
            {asset.files.posterMobile && (
              <source media="(max-width: 767px)" srcSet={asset.files.posterMobile} />
            )}
            <img
              className="art__media"
              src={asset.files.poster}
              alt=""
              decoding="async"
              loading={eager ? 'eager' : 'lazy'}
              fetchPriority={eager ? 'high' : 'auto'}
            />
          </picture>
        ) : (
          <ArtworkPlaceholder asset={asset} />
        )}

        {allowVideo && near && (
          <video
            ref={videoRef}
            className="art__media"
            muted
            loop
            playsInline
            autoPlay
            preload="auto"
            poster={hasPoster ? asset.files.poster : undefined}
            tabIndex={-1}
          >
            <source src={asset.files.webm} type="video/webm" />
            <source src={asset.files.mp4} type="video/mp4" />
          </video>
        )}
      </div>

      {overlayValue > 0 && <div className="art__overlay" aria-hidden="true" />}

      {children && <div className="art__content">{children}</div>}
    </Tag>
  );
}
