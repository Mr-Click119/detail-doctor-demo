/* Clearly labeled stand-in shown until David's real photo is supplied.
   Flat fill, no stock photo, no AI image. */
export default function ArtworkPlaceholder({ asset, compact = false }) {
  const pos = compact ? 'center' : asset.labelPos || 'center';

  return (
    <div
      className={`art-ph art-ph--${pos}${compact ? ' art-ph--compact' : ''}`}
      role="img"
      aria-label={`Photo placeholder: ${asset.label}`}
    >
      <span className="art-ph__label">
        <span className="art-ph__name">David’s work photo goes here.</span>
        <span className="art-ph__file">{asset.label}</span>
      </span>
    </div>
  );
}
