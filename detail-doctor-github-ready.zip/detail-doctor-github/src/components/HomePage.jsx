import { useLayoutEffect } from 'react';
import '../styles/design-system.css';
import '../styles/sections.css';
import '../styles/art.css';

import Header from './home/Header';
import Hero from './home/Hero';
import Booking from './home/Booking';
import Services from './home/Services';
import TrustStrip from './home/TrustStrip';
import About from './home/About';
import WhyChooseUs from './home/WhyChooseUs';
import ContactBanner from './home/ContactBanner';
import Reviews from './home/Reviews';
import ServiceAreas from './home/ServiceAreas';
import Footer from './home/Footer';

/**
 * Homepage — approved section order.
 * Photos are labeled placeholders until David supplies real work photos.
 */
export default function HomePage() {
  // Reveals only hide content once JS is running and motion is allowed,
  // so content is always visible without JS or under reduced motion.
  useLayoutEffect(() => {
    const root = document.documentElement;
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (!reduced && 'IntersectionObserver' in window) root.classList.add('motion-ready');
    return () => root.classList.remove('motion-ready');
  }, []);

  return (
    <>
      <Header />
      <main>
        <Hero />
        <Booking />
        <Services />
        <TrustStrip />
        <About />
        <WhyChooseUs />
        <ContactBanner />
        <Reviews />
        <ServiceAreas />
      </main>
      <Footer />
    </>
  );
}
