import { about } from '../../data/company';
import { artwork } from '../../data/artwork';
import FullBleedArtwork from '../art/FullBleedArtwork';
import Reveal from '../../motion/Reveal';
import { useReveal } from '../../motion/hooks';

/* Split room: the photo bleeds off the left edge, copy sits beside it.
   Restrained parallax inside the photo only; the copy never moves. */
export default function About() {
  return (
    <section className="section section-dark about" id="about">
      {/* The observer watches the outer frame; the wipe lives on the inner
          wrapper, because a clip-path on the observed element would hide it
          from its own IntersectionObserver. */}
      <div className="about__art" ref={useReveal()}>
        <div className="about__art-inner">
          <FullBleedArtwork asset={artwork.about} fill="fill" parallax={40} eager />
        </div>
      </div>

      <div className="about__text">
        <div className="stack">
          <Reveal as="h2" className="heading-lg">About The Detail Doctor</Reveal>
          <Reveal className="stack about__body" delay={160}>
            {about.paragraphs.map((paragraph, i) => (
              <p key={i} className="body-text">{paragraph}</p>
            ))}
          </Reveal>
        </div>
      </div>
    </section>
  );
}
