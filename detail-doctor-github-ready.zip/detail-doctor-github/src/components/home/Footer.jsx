import { company, navigation, services, facebook } from '../../data/company';

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="section section-chalk site-footer">
      <div className="inner site-footer__grid">
        <div className="site-footer__col">
          <img
            className="site-footer__logo"
            src={company.logo}
            alt={company.logoAlt}
            width="112"
            height="112"
            loading="lazy"
          />
          <p className="subheading">{company.name}</p>
          <p className="label">{company.businessType} · {company.primaryServiceArea}</p>
        </div>

        <div className="site-footer__col">
          <p className="site-footer__label">Pages</p>
          {navigation.map((item) => (
            <a key={item.href} href={item.href} className="site-footer__link">
              {item.label}
            </a>
          ))}
          <a href="#booking" className="site-footer__link">Request a Quote</a>
        </div>

        <div className="site-footer__col">
          <p className="site-footer__label">Services</p>
          {services.map((service) => (
            <span key={service.id} className="site-footer__link">{service.name}</span>
          ))}
        </div>

        <div className="site-footer__col">
          <p className="site-footer__label">Contact</p>
          <a href={company.phoneHref} className="site-footer__phone" aria-label={`Call ${company.phone}`}>
            {company.phone}
          </a>
          {company.email.publish && company.email.value && (
            <a href={`mailto:${company.email.value}`} className="site-footer__link">
              {company.email.value}
            </a>
          )}
          <p className="site-footer__label site-footer__label--spaced">Follow</p>
          <a
            href={facebook.url || '#reviews'}
            className="site-footer__link"
            {...(facebook.url ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
          >
            Facebook
          </a>
        </div>
      </div>

      <div className="inner site-footer__base">
        <p className="label">© {year} {company.name}. Owned and operated by David.</p>
      </div>
    </footer>
  );
}
