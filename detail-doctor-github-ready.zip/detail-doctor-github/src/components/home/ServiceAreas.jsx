import { serviceAreas, company } from '../../data/company';
import { artwork } from '../../data/artwork';
import FullBleedArtwork from '../art/FullBleedArtwork';
import Reveal from '../../motion/Reveal';

/* Wide photo band, then the service area as real HTML text.
   The town list renders only once David confirms it (publish: true). */
export default function ServiceAreas() {
  return (
    <section id="service-areas" aria-labelledby="areas-title">
      <FullBleedArtwork
        asset={artwork.serviceAreas}
        fill="container"
        parallax={30}
        scaleFrom={1}
        scaleTo={1.03}
      />

      <div className="section section-dark section-pad-lg">
        <Reveal className="inner areas">
          <div className="stack areas__intro">
            <h2 className="heading-lg" id="areas-title">Where we work</h2>
            <p className="body-text">
              Mobile detailing based in {company.primaryServiceArea}. Call or
              request a quote to check service at your location.
            </p>
          </div>

          {serviceAreas.publish && serviceAreas.towns.length ? (
            <ul className="areas__list">
              {serviceAreas.towns.map((area) => (
                <li key={area} className="areas__item">{area}</li>
              ))}
            </ul>
          ) : (
            <div className="row areas__actions">
              <a href="#booking" className="cta-button">Request a Quote</a>
              <a href={company.phoneHref} className="cta-secondary">
                Call {company.phone}
              </a>
            </div>
          )}
        </Reveal>
      </div>
    </section>
  );
}
