import { useEffect, useRef } from 'react';
import { useState } from 'react';
import { company, services, quoteForm } from '../../data/company';
import { artwork } from '../../data/artwork';
import FullBleedArtwork from '../art/FullBleedArtwork';
import { useMediaQuery, useReducedMotion } from '../../motion/hooks';
import { trackProgress } from '../../motion/scrollProgress';

/* Multi-step scroll-storytelling quote-request section.
   Desktop (≥1200px, ≥700px, no reduced motion): painting stays pinned while
   the visitor scrolls through 4 story steps. The Ink panel fades between
   messages without jumping position. Step 4 reveals the quote form.
   Everything else: static band + immediate form, as before. */

const STAGE_QUERY = '(min-width: 1200px) and (min-height: 700px)';

const STEPS = [
  {
    id: 'vehicle',
    num: '01',
    heading: 'Tell us about your vehicle.',
    body: 'Year, make, and model help us plan the right care.',
  },
  {
    id: 'care',
    num: '02',
    heading: 'Choose the care it needs.',
    body: 'Full detail, interior, or exterior — or tell us what you have in mind.',
  },
  {
    id: 'when-where',
    num: '03',
    heading: 'Pick the best time and location.',
    body: 'We come to you. Let us know where your vehicle will be.',
  },
];

/* The form step is step index 3. */
const TOTAL_STEPS = STEPS.length + 1; // 4

export default function Booking() {
  const tallScreen = useMediaQuery(STAGE_QUERY, true);
  const reduced = useReducedMotion();
  const staged = tallScreen && !reduced;

  const stageRef = useRef(null);
  const stickyRef = useRef(null);

  /* Scroll driver: writes --progress (0-1) and --step (0-3) onto the
     stage element. Only runs when staged. */
  useEffect(() => {
    if (!staged || !stageRef.current) return undefined;
    const el = stageRef.current;
    const cleanup = trackProgress(el, 'sticky');

    let raf = 0;
    function update() {
      raf = 0;
      const progress = parseFloat(el.style.getPropertyValue('--progress') || '0');
      /* Map 0-1 onto 0-(TOTAL_STEPS-1), then floor to get integer step. */
      const raw = progress * TOTAL_STEPS;
      const step = Math.min(Math.floor(raw), TOTAL_STEPS - 1);
      /* Write as a data-attribute so CSS can target it reliably. */
      const panel = el.querySelector('.booking-panel--story');
      if (panel) panel.dataset.step = step;
    }

    function onScroll() {
      if (!raf) raf = requestAnimationFrame(update);
    }

    window.addEventListener('scroll', onScroll, { passive: true });
    update();
    return () => {
      window.removeEventListener('scroll', onScroll);
      if (raf) cancelAnimationFrame(raf);
      cleanup();
    };
  }, [staged]);

  /* --- Non-staged layout (mobile / tablet / reduced motion) ---
     Static photo band + immediate form. */
  if (!staged) {
    return (
      <section
        className="booking-stage"
        id="booking"
        aria-labelledby="booking-title"
      >
        <div className="booking-stage__sticky">
          <div className="booking-stage__art">
            <FullBleedArtwork
              asset={artwork.booking}
              fill="fill"
              track={false}
              eager
            />
          </div>
          <div className="booking-stage__panel-wrap">
            <div className="booking-panel section-dark">
              <BookingForm />
            </div>
          </div>
        </div>
      </section>
    );
  }

  /* --- Staged layout (desktop) --- */
  return (
    <section
      ref={stageRef}
      className="booking-stage booking-stage--staged"
      id="booking"
      aria-labelledby="booking-title"
    >
      <div ref={stickyRef} className="booking-stage__sticky">
        {/* Photo: gentle parallax + scale, anchored so nothing is cropped */}
        <div className="booking-stage__art">
          <FullBleedArtwork
            asset={artwork.booking}
            fill="fill"
            track={false}
            eager
          />
        </div>

        {/* Panel: stable position, children cross-fade between steps */}
        <div className="booking-stage__panel-wrap">
          <div className="booking-panel booking-panel--story section-dark" role="region" aria-live="polite" data-step="0">

            {/* Steps 0-2: editorial messages */}
            {STEPS.map((step, i) => (
              <div
                key={step.id}
                className="booking-story-step"
                data-step={i}
                aria-hidden={undefined}
              >
                <span className="booking-step-num label">{step.num}</span>
                <h2
                  className="heading-lg booking-story-heading"
                  id={i === 0 ? 'booking-title' : undefined}
                >
                  {step.heading}
                </h2>
                <p className="body-text booking-story-body">{step.body}</p>
              </div>
            ))}

            {/* Step 3: the actual form */}
            <div className="booking-story-step booking-story-step--form" data-step={3}>
              <BookingForm titleId="quote-form-title" />
            </div>

            {/* Hairline progress dots */}
            <div className="booking-progress" aria-hidden="true">
              {Array.from({ length: TOTAL_STEPS }).map((_, i) => (
                <span key={i} className="booking-progress__dot" data-dot={i} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* Quote form — visually complete, intentionally NOT connected.
   Submitting validates the fields and shows an honest notice; nothing is
   sent anywhere. Wire `quoteForm.endpoint` in company.js to connect. */
function BookingForm({ titleId = 'booking-title' }) {
  const [notice, setNotice] = useState(false);

  function handleSubmit(e) {
    e.preventDefault();
    if (!quoteForm.connected) setNotice(true);
  }

  return (
    <>
      <div className="booking-panel__intro">
        <span className="booking-step-num label">04</span>
        <h2 className="heading-md" id={titleId}>Request a quote</h2>
        <p className="body-text">
          Share a few details about your vehicle and where it will be.
        </p>
      </div>

      <form className="booking-panel__form" onSubmit={handleSubmit}>
        <div className="booking__field">
          <label htmlFor="quote-name">Name</label>
          <input id="quote-name" name="name" type="text" autoComplete="name" required />
        </div>

        <div className="booking__field">
          <label htmlFor="quote-phone">Phone number</label>
          <input
            id="quote-phone"
            name="phone"
            type="tel"
            autoComplete="tel"
            placeholder="(707) 000-0000"
            required
          />
        </div>

        <div className="booking__field">
          <label htmlFor="quote-email">Email</label>
          <input id="quote-email" name="email" type="email" autoComplete="email" />
        </div>

        <div className="booking__field">
          <label htmlFor="quote-vehicle">Vehicle year / make / model</label>
          <input
            id="quote-vehicle"
            name="vehicle"
            type="text"
            placeholder="e.g. 2018 Toyota Tacoma"
            required
          />
        </div>

        <div className="booking__field">
          <label htmlFor="quote-service">Service needed</label>
          <select id="quote-service" name="service" defaultValue="" required>
            <option value="" disabled>Select a service</option>
            {services.map((s) => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
            <option value="not-sure">Not sure yet</option>
          </select>
        </div>

        <div className="booking__field">
          <label htmlFor="quote-date">Preferred date</label>
          <input id="quote-date" name="date" type="date" />
        </div>

        <div className="booking__field booking__field--wide">
          <label htmlFor="quote-location">Service location</label>
          <input
            id="quote-location"
            name="location"
            type="text"
            autoComplete="street-address"
            placeholder="Address or town where the vehicle will be"
            required
          />
        </div>

        <div className="booking__field booking__field--wide">
          <label htmlFor="quote-message">Message</label>
          <textarea
            id="quote-message"
            name="message"
            rows={3}
            placeholder="Anything we should know about the vehicle or the location"
          />
        </div>

        <div className="booking__submit">
          <button type="submit" className="cta-button">Send quote request</button>
          {notice && (
            <p className="booking__notice" role="status">
              This form isn’t connected yet, so nothing was sent. To request a
              quote now, call <a href={company.phoneHref}>{company.phone}</a>.
            </p>
          )}
        </div>
      </form>
    </>
  );
}
