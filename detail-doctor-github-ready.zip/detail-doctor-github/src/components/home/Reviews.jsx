import { facebook } from '../../data/company';
import Reveal from '../../motion/Reveal';

/* Simple trust section. No review text is written or shown here; the
   Facebook figures render only once David confirms them (publish: true). */
export default function Reviews() {
  const stats = [facebook.recommendedPercent, facebook.reviewCount];
  const showStats = stats.every((s) => s.publish && s.value);

  return (
    <section className="section section-light section-pad-lg reviews" id="reviews">
      <Reveal className="inner reviews__inner">
        <p className="label">Reviews</p>
        <h2 className="heading-lg">Recommended by customers on Facebook</h2>
        {showStats && (
          <p className="reviews__stat">
            {facebook.recommendedPercent.value} recommended from {facebook.reviewCount.value} reviews
          </p>
        )}
        <div className="row reviews__actions">
          {/* Placeholder link until the Facebook page URL is confirmed. */}
          <a
            href={facebook.url || '#reviews'}
            className="cta-button"
            {...(facebook.url ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
          >
            View Facebook Page
          </a>
        </div>
      </Reveal>
    </section>
  );
}
