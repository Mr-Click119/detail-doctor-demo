import { trustSignals } from '../../data/company';
import Reveal from '../../motion/Reveal';

/* Typographic only. Large serif values against small utility labels.
   Confirmed facts only. */
export default function TrustStrip() {
  return (
    <section className="section section-light trust" aria-label="At a glance">
      <dl className="inner trust__grid" style={{ '--count': trustSignals.length }}>
        {trustSignals.map((signal, i) => (
          <Reveal key={signal.label} className="trust__item" delay={i * 90}>
            <dt className="stat-label trust__label">{signal.label}</dt>
            <dd className="trust__value">{signal.value}</dd>
          </Reveal>
        ))}
      </dl>
    </section>
  );
}
