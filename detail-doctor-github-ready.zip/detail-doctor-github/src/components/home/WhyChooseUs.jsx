import { differentiators } from '../../data/company';
import Reveal from '../../motion/Reveal';

/* Quiet section: sticky heading on desktop, hairline-divided list. */
export default function WhyChooseUs() {
  return (
    <section className="section section-light why" id="why-mobile">
      <div className="inner why__inner">
        <div className="why__head">
          <Reveal as="h2" className="heading-lg">Why mobile detailing</Reveal>
        </div>

        <div className="why__list">
          {differentiators.map((item) => (
            <Reveal key={item.id} className="why__item">
              <h3 className="subheading">{item.title}</h3>
              <p className="body-text">{item.body}</p>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
