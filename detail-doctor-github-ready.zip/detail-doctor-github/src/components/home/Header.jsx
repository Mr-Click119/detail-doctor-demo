import { useState } from 'react';
import { company, navigation } from '../../data/company';

export default function Header() {
  const [open, setOpen] = useState(false);

  return (
    <header className="site-header">
      <div className="site-header__bar">
        <a href="#top" className="site-header__brand" aria-label={`${company.name} home`}>
          <img
            className="site-header__logo"
            src={company.logo}
            alt=""
            width="56"
            height="56"
          />
          <span className="site-header__name">{company.shortName}</span>
        </a>

        <nav className="site-header__nav" aria-label="Primary">
          {navigation.map((item) => (
            <a key={item.href} href={item.href} className="site-header__link">
              {item.label}
            </a>
          ))}
        </nav>

        <div className="site-header__actions">
          <a href={company.phoneHref} className="site-header__phone">
            {company.phone}
          </a>
          <a href="#booking" className="cta-button">Request a Quote</a>
        </div>

        <a href={company.phoneHref} className="site-header__call" aria-label={`Call ${company.phone}`}>
          Call
        </a>

        <button
          type="button"
          className="site-header__toggle"
          aria-expanded={open}
          aria-controls="mobile-menu"
          onClick={() => setOpen((v) => !v)}
        >
          {open ? 'Close' : 'Menu'}
        </button>
      </div>

      {open && (
        <div className="site-header__mobile" id="mobile-menu">
          {navigation.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="site-header__link"
              onClick={() => setOpen(false)}
            >
              {item.label}
            </a>
          ))}
          <a href={company.phoneHref} className="site-header__phone">
            Call {company.phone}
          </a>
          <a href="#booking" className="cta-button" onClick={() => setOpen(false)}>
            Request a Quote
          </a>
        </div>
      )}
    </header>
  );
}
