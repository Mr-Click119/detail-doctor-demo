import { company } from '../../data/company';

/* Typography-led. No artwork, no video. One entrance moment on load. */
export default function Hero() {
  return (
    <section className="section section-light hero" id="top">
      <div className="hero__inner">
        <div className="hero__cluster">
          <p className="label">{company.primaryServiceArea}</p>
          <h1 className="heading hero__headline">
            Mobile auto detailing across Humboldt County.
          </h1>
          <p className="body-text">
            Professional care for your vehicle, wherever you are.
          </p>
          <div className="row hero__actions">
            <a href="#booking" className="cta-button">Request a Quote</a>
            <a href={company.phoneHref} className="cta-secondary">
              Call {company.phone}
            </a>
          </div>
        </div>
      </div>

      <div className="hero__wordmark-wrap" aria-hidden="true">
        <p className="hero__wordmark">{company.shortName}</p>
      </div>
    </section>
  );
}
