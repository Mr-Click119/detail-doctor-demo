import { services } from '../../data/company';
import { artwork } from '../../data/artwork';
import CircularArtwork from '../art/CircularArtwork';
import Reveal from '../../motion/Reveal';
import { useScrollProgress } from '../../motion/hooks';

/* One gallery wall. The heading arrives first, then each photo rises
   into place as it enters view. Name, photo, and summary sit in the same
   moving group. Alternating items drift a few pixels against each other.
   The list length follows `services` in company.js. */
function ServiceItem({ service, art, index }) {
  const ref = useScrollProgress('pass');

  return (
    <li
      ref={ref}
      className="services__item"
      style={{ '--dir': index % 2 === 0 ? 1 : -1, '--i': index }}
    >
      <div className="services__group">
        <h3 className="subheading services__name">{service.name}</h3>
        <CircularArtwork asset={art} index={index} alt={`${service.name} by The Detail Doctor`} />
        <p className="body-text services__summary">{service.summary}</p>
        <a href="#booking" className="text-link services__link">
          Request a quote<span className="visually-hidden"> for {service.name}</span>
        </a>
      </div>
    </li>
  );
}

export default function Services() {
  return (
    <section className="section section-dark services" id="services">
      <div className="inner">
        <Reveal as="h2" className="display services__title">Services</Reveal>

        <ul className="services__list" style={{ '--count': services.length }}>
          {services.map((service, i) => (
            <ServiceItem key={service.id} service={service} art={artwork.services[i]} index={i} />
          ))}
        </ul>
      </div>
    </section>
  );
}
