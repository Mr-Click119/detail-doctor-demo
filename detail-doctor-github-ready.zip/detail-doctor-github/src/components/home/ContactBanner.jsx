import { company } from '../../data/company';
import { artwork } from '../../data/artwork';
import FullBleedArtwork from '../art/FullBleedArtwork';
import Reveal from '../../motion/Reveal';

/* Wide photo, flat overlay, one obvious action. */
export default function ContactBanner() {
  return (
    <FullBleedArtwork
      as="section"
      asset={artwork.contact}
      fill="container"
      parallax={26}
      scaleFrom={1}
      scaleTo={1.04}
      className="section section-dark contact-banner"
      id="contact"
      aria-labelledby="contact-title"
    >
      <Reveal className="contact-banner__inner">
        <h2 className="heading-lg" id="contact-title">Ready when your vehicle is.</h2>
        <p className="body-text">Mobile auto detailing across Humboldt County.</p>
        <div className="row contact-banner__actions">
          <a href="#booking" className="cta-button">Request a Quote</a>
          <a href={company.phoneHref} className="cta-secondary">
            Call {company.phone}
          </a>
        </div>
      </Reveal>
    </FullBleedArtwork>
  );
}
