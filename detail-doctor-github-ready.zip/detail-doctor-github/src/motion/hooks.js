import { useEffect, useRef, useState } from 'react';
import { trackProgress } from './scrollProgress';

const REDUCED = '(prefers-reduced-motion: reduce)';
export const DESKTOP = '(min-width: 768px)';

export function useMediaQuery(query, fallback = false) {
  const [matches, setMatches] = useState(() =>
    typeof window === 'undefined' ? fallback : window.matchMedia(query).matches
  );
  useEffect(() => {
    const mql = window.matchMedia(query);
    const onChange = () => setMatches(mql.matches);
    onChange();
    mql.addEventListener('change', onChange);
    return () => mql.removeEventListener('change', onChange);
  }, [query]);
  return matches;
}

export const useReducedMotion = () => useMediaQuery(REDUCED, false);

/* Attach scroll progress to a ref. Disabled under reduced motion. */
export function useScrollProgress(mode = 'pass', enabled = true) {
  const ref = useRef(null);
  const reduced = useReducedMotion();
  useEffect(() => {
    if (!enabled || reduced || !ref.current) return undefined;
    return trackProgress(ref.current, mode);
  }, [mode, enabled, reduced]);
  return ref;
}

/* One-time reveal. Adds `is-revealed` once the element enters.
   Content is only hidden when <html> has .motion-ready, so it stays
   visible without JavaScript and under reduced motion. */
let revealObserver = null;
function getRevealObserver() {
  if (!revealObserver) {
    revealObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add('is-revealed');
            revealObserver.unobserve(e.target);
          }
        });
      },
      { threshold: 0.15, rootMargin: '0px 0px -8% 0px' }
    );
  }
  return revealObserver;
}

export function useReveal() {
  const ref = useRef(null);
  useEffect(() => {
    const el = ref.current;
    if (!el) return undefined;
    if (!('IntersectionObserver' in window)) {
      el.classList.add('is-revealed');
      return undefined;
    }
    const io = getRevealObserver();
    io.observe(el);
    return () => io.unobserve(el);
  }, []);
  return ref;
}

/* True once the element is within `margin` of the viewport; used to
   defer video loading. Also reports current visibility for pausing. */
export function useNearViewport(margin = '400px') {
  const ref = useRef(null);
  const [near, setNear] = useState(false);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el || !('IntersectionObserver' in window)) return undefined;
    const nearIO = new IntersectionObserver(
      ([e]) => e.isIntersecting && setNear(true),
      { rootMargin: `${margin} 0px` }
    );
    const visIO = new IntersectionObserver(
      ([e]) => setVisible(e.intersectionRatio > 0.2),
      { threshold: [0, 0.2, 0.5] }
    );
    nearIO.observe(el);
    visIO.observe(el);
    return () => {
      nearIO.disconnect();
      visIO.disconnect();
    };
  }, [margin]);
  return [ref, near, visible];
}
