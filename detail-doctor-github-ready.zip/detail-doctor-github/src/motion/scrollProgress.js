/* Shared scroll-progress engine.
   One passive scroll listener + one rAF per frame for the whole page.
   Only elements currently near the viewport are measured.
   Writes a single CSS variable (--progress, 0..1) on each tracked element;
   CSS turns that into transforms. React never re-renders on scroll.

   Modes
   - "pass":   0 when the element's top enters the bottom of the viewport,
               1 when its bottom leaves the top.   (parallax bands)
   - "sticky": 0 when the element's top reaches the viewport top,
               1 when its bottom reaches the viewport bottom. (sticky regions) */

const active = new Set();
let observer = null;
let ticking = false;

function measure() {
  ticking = false;
  const vh = window.innerHeight;
  active.forEach((el) => {
    const r = el.getBoundingClientRect();
    let p;
    if (el.dataset.progressMode === 'sticky') {
      const distance = r.height - vh;
      p = distance > 0 ? -r.top / distance : 0;
    } else {
      p = (vh - r.top) / (vh + r.height);
    }
    p = p < 0 ? 0 : p > 1 ? 1 : p;
    el.style.setProperty('--progress', p.toFixed(4));
  });
}

function schedule() {
  if (!ticking) {
    ticking = true;
    requestAnimationFrame(measure);
  }
}

function ensureObserver() {
  if (observer) return;
  observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((e) => {
        if (e.isIntersecting) active.add(e.target);
        else active.delete(e.target);
      });
      schedule();
    },
    { rootMargin: '120px 0px' }
  );
  window.addEventListener('scroll', schedule, { passive: true });
  window.addEventListener('resize', schedule, { passive: true });
}

export function trackProgress(el, mode = 'pass') {
  if (typeof window === 'undefined' || !('IntersectionObserver' in window)) {
    return () => {};
  }
  ensureObserver();
  el.dataset.progressMode = mode;
  observer.observe(el);
  schedule();
  return () => {
    observer.unobserve(el);
    active.delete(el);
    el.style.removeProperty('--progress');
  };
}
