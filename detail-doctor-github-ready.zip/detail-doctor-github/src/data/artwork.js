/* ============================================
   PHOTO SLOTS
   ============================================
   Every image area on the homepage. Components read paths, focal
   points, and crops from here.

   No AI-generated images are used. Each slot shows a labeled
   placeholder ("David's work photo goes here.") until a real photo of
   David's work is supplied.

   To activate a photo: drop the file at its path, then set the
   matching `ready.poster` flag to true. While false, no network
   request is made, so there are no broken images.

   Photo direction: David's own vehicles and detailing work - glossy
   paint, careful hand work, clean interiors, tools, reflections, and
   the mobile setup. No stock photos, no fake before/after pairs.
   ============================================ */

export const photoGuidance =
  "Real photos of David's own work only. Landscape for wide slots, square for circles. Avoid customer licence plates and faces unless they agreed to appear.";

export const artwork = {
  booking: {
    id: 'booking',
    section: 'Quote request',
    label: 'Quote section - wide photo',
    kind: 'static',
    files: {
      poster: '/media/booking/booking.webp',
      posterMobile: '/media/booking/booking-mobile.webp',
    },
    ready: { poster: false },
    aspect: { desktop: '16 / 9', mobile: '4 / 5' },
    focal: { desktop: '50% 50%', mobile: '50% 50%' },
    labelPos: 'right',
    mobileCrop: 'Separate 4:5 crop of the same photo',
    subject: 'A vehicle being detailed on site, with the mobile setup visible at one side.',
    negativeSpace: 'Centre half of the width sits under the quote panel; keep the subject to the sides.',
    textOver: 'Yes: centred quote panel',
    overlay: 0.08,
  },

  // One circular photo per service, matched by index to `services`.
  services: [
    {
      id: 'full-detail',
      label: 'Full Detail photo',
      subject: 'A finished vehicle showing paint reflection.',
    },
    {
      id: 'interior-detailing',
      label: 'Interior Detailing photo',
      subject: 'A clean interior: seats, console, or dashboard.',
    },
    {
      id: 'exterior-detailing',
      label: 'Exterior Detailing photo',
      subject: 'Close-up of hand work on paint, wheels, or trim.',
    },
  ].map((s) => ({
    ...s,
    section: 'Services',
    kind: 'static',
    files: { poster: `/media/services/${s.id}.webp` },
    ready: { poster: false },
    aspect: { desktop: '1 / 1', mobile: '1 / 1' },
    focal: { desktop: '50% 50%', mobile: '50% 50%' },
    mobileCrop: 'Same square crop at every size',
    negativeSpace: 'Keep the subject inside the central 70% so the circle never clips it.',
    textOver: 'No',
  })),

  about: {
    id: 'about',
    section: 'About',
    label: 'About section - tall photo',
    kind: 'static',
    files: { poster: 'media/about/about.webp' },
    ready: { poster: true },
    aspect: { desktop: '4 / 5', mobile: '4 / 5' },
    focal: { desktop: '50% 50%', mobile: '50% 50%' },
    labelPos: 'center',
    mobileCrop: 'Same 4:5 frame',
    subject: "David's detailing tools and setup, or David at work if he wants to appear.",
    negativeSpace: 'Subject within the central half of the width.',
    textOver: 'No (text sits beside it)',
  },

  contact: {
    id: 'contact',
    section: 'Contact banner',
    label: 'Contact banner - wide photo',
    kind: 'static',
    files: {
      poster: '/media/contact/contact.webp',
      posterMobile: '/media/contact/contact-mobile.webp',
    },
    ready: { poster: false },
    aspect: { desktop: '21 / 9', mobile: '4 / 5' },
    focal: { desktop: '50% 50%', mobile: '50% 50%' },
    labelPos: 'top-left',
    mobileCrop: 'Separate 4:5 crop',
    subject: 'A finished, clean vehicle with calm space around it for the headline.',
    negativeSpace: 'Middle band kept calm for the centred headline and buttons.',
    textOver: 'Yes: headline, one line, two buttons',
    overlay: 0.5,
  },

  serviceAreas: {
    id: 'service-area',
    section: 'Service area',
    label: 'Service area - wide photo',
    kind: 'static',
    files: { poster: '/media/areas/service-area.webp' },
    ready: { poster: false },
    aspect: { desktop: '21 / 9', mobile: '4 / 3' },
    focal: { desktop: '50% 50%', mobile: '50% 50%' },
    labelPos: 'center',
    mobileCrop: 'Centre of the frame',
    subject: 'A job on location somewhere in Humboldt County.',
    negativeSpace: 'None',
    textOver: 'No',
  },
};

export const artworkList = [
  artwork.booking,
  ...artwork.services,
  artwork.about,
  artwork.contact,
  artwork.serviceAreas,
];
