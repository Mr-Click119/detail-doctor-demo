/* ============================================
   COMPANY DATA — THE DETAIL DOCTOR AUTO DETAIL
   ============================================
   Single source of truth for every business fact on the site.

   Rules for this file:
   - Only facts the owner has confirmed are published.
   - Anything awaiting David's confirmation carries `publish: false`
     and is NOT rendered anywhere on the page.
   - No prices, warranties, certifications, years in business,
     customer reviews, or service claims are written here.
   ============================================ */

import logoUrl from '../assets/the-detail-doctor-logo.png';

export const company = {
  name: 'The Detail Doctor Auto Detail',
  shortName: 'The Detail Doctor',
  // Provided logo, used unaltered. Replace the file if a better one arrives.
  logo: logoUrl,
  logoAlt: 'The Detail Doctor Car Detailing, Humboldt County, California',
  ownerName: 'David Reynosa', // spelling to confirm (email uses "reynoza")
  businessType: 'Mobile auto detailing',
  primaryServiceArea: 'Humboldt County, California',
  phone: '(707) 442-3597',
  phoneHref: 'tel:+17074423597',

  // Held until David confirms he wants it public. The address on file is
  // kept in this comment only (comments are stripped from the build):
  //   reynoza.david@yahoo.com
  email: { value: null, publish: false },
};

/* Quote form — visual only. Not connected to email or any form service. */
export const quoteForm = {
  connected: false,
  // When a provider is chosen, put its endpoint here and set connected: true.
  endpoint: null,
};

/* Services — kept flexible until David confirms his exact list.
   Mobile service is how every job is delivered, not a separate package,
   so it is deliberately not listed here. Summaries make no claims about
   what is included; they invite a quote conversation instead. */
export const services = [
  {
    id: 'full-detail',
    name: 'Full Detail',
    summary: 'Ask about a complete detail for your vehicle.',
    confirmed: false,
  },
  {
    id: 'interior-detailing',
    name: 'Interior Detailing',
    summary: 'Ask about care for your vehicle’s interior.',
    confirmed: false,
  },
  {
    id: 'exterior-detailing',
    name: 'Exterior Detailing',
    summary: 'Ask about care for your vehicle’s exterior.',
    confirmed: false,
  },
];

/* Trust strip — confirmed facts only. */
export const trustSignals = [
  { value: 'Mobile', label: 'Detailing that comes to you' },
  { value: 'Humboldt', label: 'County, California — primary service area' },
  { value: 'Quote', label: 'Request one online or by phone' },
];

/* Facebook social proof. Figures held until David confirms they are
   current and wants them public. Figures on file (comment only, not
   shipped): 98% recommended, 39 reviews. */
export const facebook = {
  pageName: 'The Detail Doctor Auto Detail',
  url: null, // placeholder — add the real page URL when confirmed
  recommendedPercent: { value: null, publish: false },
  reviewCount: { value: null, publish: false },
};

/* Communities — held until David confirms the list. Towns on file
   (comment only, not shipped): Eureka, Arcata, Fortuna, Rio Dell,
   Garberville. */
export const serviceAreas = {
  publish: false,
  towns: [],
};

/* About — short and factual. No history, credentials, or claims. */
export const about = {
  paragraphs: [
    'The Detail Doctor Auto Detail is a mobile auto detailing service in Humboldt County, California. Instead of asking you to bring your vehicle to a shop, David brings professional detailing products and equipment to you.',
    'Tell us about your vehicle and what it needs, and we’ll talk through the right care for it.',
  ],
};

/* Why mobile — drawn only from confirmed facts. */
export const differentiators = [
  {
    id: 'comes-to-you',
    title: 'We come to you',
    body: 'Your vehicle is detailed where it already is, so there’s no drop-off or pick-up to plan around.',
  },
  {
    id: 'local',
    title: 'Local to Humboldt County',
    body: 'The Detail Doctor Auto Detail is a Humboldt County business, owned and operated by David.',
  },
  {
    id: 'simple-request',
    title: 'A simple quote request',
    body: 'Call (707) 442-3597, or send a request with your vehicle and where it will be.',
  },
];

/* Navigation */
export const navigation = [
  { label: 'Services', href: '#services' },
  { label: 'About', href: '#about' },
  { label: 'Reviews', href: '#reviews' },
  { label: 'Service area', href: '#service-areas' },
];
