# Photo locations

Real photos of David's work go here — no stock or AI-generated images.
File names must match `src/data/artwork.js`. After adding a file, set its
`ready.poster` flag to true; until then the page shows a labeled
"David's work photo goes here." placeholder and never requests the file.

| Folder     | Files                                                          |
|------------|----------------------------------------------------------------|
| booking/   | booking.webp (16:9), booking-mobile.webp (4:5)                 |
| services/  | full-detail.webp, interior-detailing.webp, exterior-detailing.webp (square) |
| about/     | about.webp (4:5)                                               |
| contact/   | contact.webp (21:9), contact-mobile.webp (4:5)                 |
| areas/     | service-area.webp (21:9)                                       |
