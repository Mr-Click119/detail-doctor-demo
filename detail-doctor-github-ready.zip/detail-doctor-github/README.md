# The Detail Doctor Auto Detail — Website

Homepage for The Detail Doctor Auto Detail, a mobile auto detailing
business in Humboldt County, California. React 18 + Vite 5.

## Status

- Copy converted from an earlier demo layout; layout, motion and
  responsive behaviour are unchanged.
- **Photos:** every image area shows a labeled placeholder ("David's work
  photo goes here.") until real photos of David's work are supplied. See
  `PHOTO-SLOTS.md`.
- **Quote form:** visually complete but **not connected**. Submitting
  shows a notice and sends nothing.
- **Held until David confirms** (flagged `publish: false` in
  `src/data/company.js`, not rendered): email address, Facebook
  98% / 39-review figures, the list of service towns.
- **Placeholders:** Facebook page URL (`facebook.url`), final service list
  and descriptions (`services[]`, `confirmed: false`).

## Run locally

```bash
npm install
npm run dev            # http://localhost:5173
npm run build          # static bundle in dist/
npm run build:preview  # single self-contained dist/index.html
```

## Where things live

```
src/data/company.js   All business facts (single source of truth)
src/data/artwork.js   Photo slots, paths, crops
src/components/home/  Header, Hero, Booking (quote request), Services,
                      TrustStrip, About, WhyChooseUs, ContactBanner,
                      Reviews, ServiceAreas, Footer
src/assets/           Provided logo (unaltered)
public/media/         Real photos go here
```

## Connecting the quote form later

Set `quoteForm.endpoint` and `quoteForm.connected = true` in
`company.js`, then post the form data in `handleSubmit` in
`src/components/home/Booking.jsx`.

## Quote story scroll

On desktop (≥1200px wide, ≥700px tall, no reduced motion) the quote
section pins its photo while the visitor scrolls four steps:

1. Tell us about your vehicle.
2. Choose the care it needs.
3. Pick the best time and location.
4. The quote request form.

On tablet, mobile and reduced motion, the form shows immediately.
