import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { viteSingleFile } from 'vite-plugin-singlefile';

// `--mode preview` inlines everything into one HTML file for review.
// The logo is imported as a URL normally; in preview mode it is forced
// inline (data URL) so the single file has no external references.
export default defineConfig(({ mode }) => ({
  plugins: [react(), ...(mode === 'preview' ? [viteSingleFile()] : [])],
  resolve:
    mode === 'preview'
      ? { alias: [{ find: /^(.*\.png)$/, replacement: '$1?inline' }] }
      : {},
}));
