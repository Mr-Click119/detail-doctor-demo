// Generates PHOTO-SLOTS.md from src/data/artwork.js
// Run: node scripts/build-manifest.mjs
import { writeFileSync } from 'node:fs';
import { artworkList, photoGuidance } from '../src/data/artwork.js';

const files = (a) => Object.values(a.files).map((f) => `\`/public${f}\``).join('<br>');
const rows = artworkList.map((a) =>
  `| ${a.section} | ${a.label} | ${files(a)} | ${a.aspect.desktop.replace(/ /g, '')} | ${a.subject} | ${a.textOver} |`
);

const md = `# Photo Slots

Generated from \`src/data/artwork.js\`. Edit that file, then rerun
\`node scripts/build-manifest.mjs\`.

**${artworkList.length} photo slots.** ${photoGuidance}

| Section | Slot | File(s) | Aspect | Suggested subject | Text over photo |
|---|---|---|---|---|---|
${rows.join('\n')}

## Activating a photo

1. Save the photo as WebP at the path above.
2. In \`src/data/artwork.js\`, set that slot's \`ready.poster\` to \`true\`.
3. Adjust \`focal\` if the subject sits off-centre.
`;

writeFileSync(new URL('../PHOTO-SLOTS.md', import.meta.url), md);
console.log(`Wrote PHOTO-SLOTS.md (${artworkList.length} slots)`);
