# Photo Slots

Generated from `src/data/artwork.js`. Edit that file, then rerun
`node scripts/build-manifest.mjs`.

**7 photo slots.** Real photos of David’s own work only. Landscape for wide slots, square for circles. Avoid customer licence plates and faces unless they agreed to appear.

| Section | Slot | File(s) | Aspect | Suggested subject | Text over photo |
|---|---|---|---|---|---|
| Quote request | Quote section — wide photo | `/public/media/booking/booking.webp`<br>`/public/media/booking/booking-mobile.webp` | 16/9 | A vehicle being detailed on site, with the mobile setup visible at one side. | Yes: centred quote panel |
| Services | Full Detail photo | `/public/media/services/full-detail.webp` | 1/1 | A finished vehicle showing paint reflection. | No |
| Services | Interior Detailing photo | `/public/media/services/interior-detailing.webp` | 1/1 | A clean interior: seats, console, or dashboard. | No |
| Services | Exterior Detailing photo | `/public/media/services/exterior-detailing.webp` | 1/1 | Close-up of hand work on paint, wheels, or trim. | No |
| About | About section — tall photo | `/public/media/about/about.webp` | 4/5 | David’s detailing tools and setup, or David at work if he wants to appear. | No (text sits beside it) |
| Contact banner | Contact banner — wide photo | `/public/media/contact/contact.webp`<br>`/public/media/contact/contact-mobile.webp` | 21/9 | A finished, clean vehicle with calm space around it for the headline. | Yes: headline, one line, two buttons |
| Service area | Service area — wide photo | `/public/media/areas/service-area.webp` | 21/9 | A job on location somewhere in Humboldt County. | No |

## Activating a photo

1. Save the photo as WebP at the path above.
2. In `src/data/artwork.js`, set that slot's `ready.poster` to `true`.
3. Adjust `focal` if the subject sits off-centre.
